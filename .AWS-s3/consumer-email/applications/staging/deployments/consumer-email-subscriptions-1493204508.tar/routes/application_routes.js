"use strict";
const EmailController = require('../controllers/email_subscription_controller.js');

const routes = {
    defineRoutes: function(router, routeAuthenticator) {
        var _controller = new EmailController();

        //Status
        router.get('/status', function(req, res, next) {
            res.data = "OK";
            next();
        });

        //Email Subscription
        router.get('/email/subscription/get', routeAuthenticator, function(req, res, next) {
            if (req.headers[process.env.AUTH_HEADER_KEY] != process.env.AUTH_HEADER_VALUE) {
                return next(new middleware.BaseHttpError('Unauthorized', 'Unauthorized', 401));
            }

            _controller.get(req, res, next);
        });

        router.put('/email/subscription/update', routeAuthenticator, function(req, res, next) {
            if (req.headers[process.env.AUTH_HEADER_KEY] != process.env.AUTH_HEADER_VALUE) {
                return next(new middleware.BaseHttpError('Unauthorized', 'Unauthorized', 401));
            }

            _controller.update(req, res, next);
        });

        router.post('/email/subscription/create', routeAuthenticator, function(req, res, next) {
            if (req.headers[process.env.AUTH_HEADER_KEY] != process.env.AUTH_HEADER_VALUE) {
                return next(new middleware.BaseHttpError('Unauthorized', 'Unauthorized', 401));
            }

            _controller.create(req, res, next);
        });
    }

};

module.exports = routes;