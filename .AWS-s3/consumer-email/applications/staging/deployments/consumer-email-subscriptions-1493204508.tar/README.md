# consumer-email-subscriptions
Consumer Core Services Email Subscriptsion api
