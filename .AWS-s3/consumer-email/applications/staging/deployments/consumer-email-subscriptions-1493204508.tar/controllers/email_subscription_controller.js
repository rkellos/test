"use strict";
const middleware = require('@careerbuilder/consumer-services-middleware');
const EmailSubscriptionService = require('../lib/services/email_subscription_service.js');

function EmailController() {
    var _self = this;
    var _service = new EmailSubscriptionService();

    _self.get = function(req, res, next) {
        
        var result = _service.getSubscription(req.data, res);

        next(null, result);//return results
    };

    _self.update = function(req, res, next) {
        
        var result = _service.updateSubscription(req.data, res);

        next(null, result);//return modified item
    };

    _self.create = function(req, res, next) {
        
        var result = _service.createSubscription(req.data, res);

        next(null, result.email_address);//return email of new item
    };
}

module.exports = EmailController;