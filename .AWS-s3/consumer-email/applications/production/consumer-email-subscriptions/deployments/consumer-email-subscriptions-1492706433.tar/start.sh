envVars=$(cat app_development.env | tr '\n' ' ')
echo $envVars
eval "$envVars node $1 bin/www"
