if (process.env.NODE_ENV === 'production' && process.env.STACK_NAME && process.env.NEW_RELIC_KEY){
  console.log('New Relic instrumentation is enabled.');
  require('newrelic');
} else {
  console.log('New Relic instrumentation is disabled. You must be in production and have process.env.STACK_NAME, process.env.NEW_RELIC_KEY set.');
}


var middleware = require('@careerbuilder/consumer-services-middleware');
var application_routes = require('./routes/application_routes.js');

var express = require('express');
var app = express();

middleware.defineRoutes(application_routes.defineRoutes);
app.use(middleware.getRouter());

module.exports = app;

