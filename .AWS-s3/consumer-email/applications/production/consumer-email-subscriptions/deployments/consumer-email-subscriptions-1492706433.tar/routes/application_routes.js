var HomeController = require('../controllers/home_controller.js');

var routes = {
  defineRoutes: function(router, routeAuthenticator){
    router.get('/status', function(req, res, next){
      res.data = "OK";
      next();
    });

    router.get('/', routeAuthenticator, function(req, res, next){
      var homeController = new HomeController();
      homeController.getIndex(req, res, next);
    });

    router.get('/error', function(req, res, next){
      var homeController = new HomeController();
      homeController.getWithError(req, res, next);
    });
  }
};

module.exports = routes;
