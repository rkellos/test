var middleware = require('@careerbuilder/consumer-services-middleware');

function HomeController(){
  this.getIndex = function(req, res, next){
    res.data = {
      test: 'blah'
    };
    next();
  };

  this.getWithError = function(req, res, next){
    next(new middleware.BaseHttpError('BadRequest', 'BadRequest', 400));
  };
}
module.exports = HomeController;
